package day_3;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class CSS_Selectors {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver driver = new FirefoxDriver();
		driver.get("https://www.google.com/");
		// driver.findElement(By.cssSelector("textarea[class='gLFyf']")).sendKeys("Pune",
		// Keys.ENTER);

	}

}
